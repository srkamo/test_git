import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Vector;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.*;

public class Main {
	
	private static HashMap<String, User> usersMap;
	private static HashMap<String, Movie> moviesMap;
	
	
	private static Vector<String> actionList;
	private static Vector<String> genreList;
	
	public static int curr;
	public static User currUser;
	
	public static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		
		parseXML(args[0]);
		setUpFollowers();
		
		firstMenu();
		
		System.out.println("Closing...GoodBye...");
		
	}
	
	private static void parseXML(String file){
		
		genreList = new Vector<String>();
		actionList = new Vector<String>();
		moviesMap = new HashMap<String,Movie>();
		usersMap = new HashMap<String, User>();
		
		try{
			
			File inputFile = new File(file);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			
			//load genres
			NodeList genres = doc.getElementsByTagName("genres");
			Element e = (Element) genres.item(0);
			for(int i = 0; i < e.getElementsByTagName("genre").getLength(); i++)
				genreList.add(e.getElementsByTagName("genre").item(i).getTextContent());
			
			//load actions
			NodeList actions = doc.getElementsByTagName("actions");
			Element e0 = (Element) actions.item(0);
			for(int i = 0; i < e0.getElementsByTagName("action").getLength(); i++)
				actionList.add(e0.getElementsByTagName("action").item(i).getTextContent());
			
			//loading movie objects
			NodeList movies = doc.getElementsByTagName("movies"); 
			Element eMov = (Element) movies.item(0);
			for(int i = 0; i < eMov.getElementsByTagName("movie").getLength(); i++){
				Element tempMv = (Element) eMov.getElementsByTagName("movie").item(i);
				
				String title =  tempMv.getElementsByTagName("title").item(0).getTextContent();
				String director =  tempMv.getElementsByTagName("director").item(0).getTextContent();
				String year =  tempMv.getElementsByTagName("year").item(0).getTextContent();
				String genre =  tempMv.getElementsByTagName("genre").item(0).getTextContent();
				String description =  tempMv.getElementsByTagName("description").item(0).getTextContent();
				String rating =  tempMv.getElementsByTagName("rating").item(0).getTextContent();
				
				NodeList writers =  tempMv.getElementsByTagName("writers");
				Element writerElement = (Element) writers.item(0);
				Vector<String> wrtrVctr = new Vector<String>();
				for(int j = 0; j < writerElement.getElementsByTagName("writer").getLength(); j++)
					wrtrVctr.add(writerElement.getElementsByTagName("writer").item(j).getTextContent());
				
				NodeList actors =  tempMv.getElementsByTagName("actors");
				Element actorElement = (Element) actors.item(0);
				Vector<String> actrVctr = new Vector<String>();
				for(int j = 0; j < actorElement.getElementsByTagName("actor").getLength(); j++)
					actrVctr.add(actorElement.getElementsByTagName("actor").item(j).getTextContent());
				
				Movie temp = new Movie(title, director, wrtrVctr, actrVctr, genre, description, year, rating);
				moviesMap.put(title, temp);
				
			}
			
			//loading user Objects
			NodeList users = doc.getElementsByTagName("users");
			Element eUsers = (Element) users.item(0);
			for(int i = 0; i < eUsers.getElementsByTagName("user").getLength(); i++){
				Element tempUsr = (Element) eUsers.getElementsByTagName("user").item(i);
				
				String username = tempUsr.getElementsByTagName("username").item(0).getTextContent();
				String password = tempUsr.getElementsByTagName("password").item(0).getTextContent();
				String fname = tempUsr.getElementsByTagName("fname").item(0).getTextContent();
				String lname = tempUsr.getElementsByTagName("lname").item(0).getTextContent();
				
				Vector<Event> feed = new Vector<Event>();
				Element feedElement = (Element) tempUsr.getElementsByTagName("feed").item(0);
				for(int j = 0; j < feedElement.getElementsByTagName("event").getLength(); j++){
					Element tempEvent = (Element) feedElement.getElementsByTagName("event").item(j);
					String action = tempEvent.getElementsByTagName("action").item(0).getTextContent();
					String movie = tempEvent.getElementsByTagName("movie").item(0).getTextContent();
					String rating = tempEvent.getElementsByTagName("rating").item(0).getTextContent();
					
					Event eTmp = new Event(action, movie, rating);
					feed.add(eTmp);
				}
				
				Vector<String> following = new Vector<String>();
				Element followingElement  = (Element) tempUsr.getElementsByTagName("following").item(0);
				for(int j = 0; j < followingElement.getElementsByTagName("username").getLength(); j++){
					String tempUsrString = followingElement.getElementsByTagName("username").item(j).getTextContent();
					following.add(tempUsrString);
				}
				
				User u = new User(following, feed, fname, lname, username, password);
				usersMap.put(username, u);

			}
			
			
			
		}catch(Exception e){
			System.out.println("exception message: " + e.getMessage());
		}
	}
	
	private static void setUpFollowers(){
		Iterator<Entry<String, User>> it = usersMap.entrySet().iterator();
		while(it.hasNext()){
			Map.Entry<String, User> pair  = (Map.Entry<String, User>) it.next();
			User u = (User) pair.getValue();
			Vector<String> following = u.getFollowing();
			for(int i = 0; i < following.size(); i++){
				User utmp = usersMap.get(following.get(i));
				utmp.addFollowers(u.getUsername());
			}
		}
	}
	
	private static void firstMenu(){
		
		System.out.println("1. Login\n2. Exit");
		
		int oneOrTwo = 0;
		
		if(scan.hasNextInt())
			oneOrTwo = scan.nextInt();
		else
			scan.next();
		
		while(oneOrTwo != 2 && oneOrTwo != 1){
			
			System.out.println("Invalid Input");
			System.out.println("1. Login\n2. Exit");
			
			if(scan.hasNextInt())
				oneOrTwo = scan.nextInt();
			else
				scan.next();
		}
		
		
		if(oneOrTwo == 1)
			login();
	}
	
	private static void login(){
		int chances = 2;
		System.out.print("Enter your username\n-> ");
		String uName = "*****";
		uName = scan.next();
		
		System.out.println("\nuName: " + uName);
		
		while(!usersMap.containsKey(uName) && chances != 0){
			System.out.print("Invalid username. You have " + chances + " chances left\n-> ");
			uName = scan.next();
			chances--; 
		}
		
		if(chances == 0)
			return;
		
		currUser = usersMap.get(uName);

		chances = 2;
		
		System.out.print("Enter your password\n-> ");
		String pass = scan.next();
		while(!currUser.getPassword().equals(pass) && chances != 0){
			System.out.print("Invalid password. You have " + chances + " chances left\n-> ");
			pass = scan.next();
			chances--;
		}
		
		if(chances == 0)
			return;
		
		loginMenu();
	}
	
	private static void loginMenu(){
		System.out.println("1. Search Users\n2. Search Movies\n3. View Feed\n4. View Profile\n5. Logout\n6. Exit");
		int choice = 0;
		
		if(scan.hasNextInt())
			choice = scan.nextInt();
		
		while(choice < 1 || choice > 6 ){
			System.out.println("Invalid Input\n");
			System.out.println("1. Search Users\n2. Search Movies\n3. View Feed\n4. View Profile\n5. Logout\n6. Exit");
			
			if(scan.hasNextInt()){
				choice = scan.nextInt();
			}
			else
				scan.next();
		}
		
		switch(choice){
		case 1:
			searchUsers();
			break;
		case 2:
			searchMovies();
			break;
		case 3:
			printFeed();
			break;
		case 4:
			printProfile();
			break;
		case 5:
			System.out.println("...Logging out...");
			firstMenu();
			break;
		case 6:
			System.out.println("Closing...GoodBye...~");
			System.exit(0);
		}

	
		
	}

	private static void printProfile(){
		
		System.out.println(currUser.getfName() + " " + currUser.getlName());
		System.out.println("username: " + currUser.getUsername());
		StringBuilder modPass = new StringBuilder(currUser.getPassword());
		for(int i = 1; i < modPass.length() - 1 ; i++)
			modPass.setCharAt(i, '*');
		System.out.println("password: " + modPass );
		System.out.println("\nfollowing:");
		for(int i = 0; i < currUser.getFollowing().size(); i++)
			System.out.println(currUser.getFollowing().get(i));
		
		System.out.println("\nfollowers:");
		for(int i = 0; i < currUser.getFollowers().size();i++)
			System.out.println(currUser.getFollowers().get(i));
		
		returnToLoginMenu();
	}
	
	private static void printFeed(){
		
		System.out.println("Feed:\n");
		
		for(int i = 0; i < currUser.getFeed().size(); i++)
			System.out.println(currUser.getUsername() + " " + currUser.getFeed().get(i).getAction() + " the movie " + currUser.getFeed().get(i).getMovieTitle());
		
		Vector<String> following = currUser.getFollowing();
		for(int i = 0; i < following.size(); i++){
			User u = usersMap.get(following.get(i));
			Vector<Event> uFeed = u.getFeed();
			for(int j = 0; j < uFeed.size(); j++)
				System.out.println(u.getUsername() + " " + uFeed.get(j).getAction() + " the movie " + uFeed.get(j).getMovieTitle());
		}
			
		returnToLoginMenu();
	}
	
	private static void searchUsers(){
		
		System.out.print("Enter the username you are searching for.\n->");
		String search = scan.next();
		Iterator<Entry<String,User>> it = usersMap.entrySet().iterator();
		
		Vector<String> uNames = new Vector<String>();
		while(it.hasNext()){
			Map.Entry<String, User> pair = (Map.Entry<String, User>) it.next();
			User u = (User) pair.getValue();
			if(u.getUsername().equalsIgnoreCase(search))
				uNames.add(u.getUsername());
		}
		
		System.out.println(uNames.size() + " result(s):");
		for(int i = 0; i < uNames.size(); i++)
			System.out.println(uNames.get(i));
		
		
		userSearchToLogin();
		
	}
	
	private static void searchMovies(){
		
		System.out.println("1. Search by Actor\n2. Search by Title\n3. Search by Genre\n4. Back to Login Menu");
		Scanner scan = new Scanner(System.in);
		int choice = 0;
		
		if(scan.hasNextInt())
			choice = scan.nextInt();
		
		System.out.println("choice: " + choice);
		
		while(choice < 1 && choice > 4){
			System.out.println("Invalid input\n1. Search by Actor\n2. Search by Title\n3. Search by Genre\n4. Back to Login Menu");
			if(scan.hasNextInt())
				choice = scan.nextInt();
			else 
				scan.next();
		}
		
		
		switch(choice){
		case 1:
			searchByActor();
			break;
		case 2:
			searchByTitle();
			break;
		case 3:
			searchByGenre();
			break;
		case 4:
			loginMenu();
			return;
		}
		
		movieSearchToLogin();
	}
	
	private static void returnToLoginMenu(){
		
		System.out.println("To go back to the login menu, please type '0'");
		Scanner scan = new Scanner(System.in);
		int login = -1;
		
		if(scan.hasNextInt())
			login = scan.nextInt();
		else
			scan.next();
		
		while(login != 0){
			System.out.println("Invalid. To go to the login menu type '0'");
			
			if(scan.hasNextInt())
				login = scan.nextInt();
			else
				scan.next();
		}
		
		loginMenu();
	}
	
	private static void userSearchToLogin(){
		
		System.out.println("Please choose from the following:\n1.Back to Login Menu\n2.Search Again\n->");
		int choice = 0;
		
		Scanner scan = new Scanner(System.in);
		if(scan.hasNextInt())
			choice = scan.nextInt();
		
		while(choice != 1 && choice != 2){
			System.out.println("Invalid input\nPlease choose from the following:\n1.Back to Login Menu\n2.Search Again\n->");
			if(scan.hasNextInt())
				choice = scan.nextInt();
			else
				scan.next();
		}
		
		
		switch(choice){
		case 1:
			loginMenu();
			break;
		case 2:
			searchUsers();
			break;
		}
	}
	
	private static void movieSearchToLogin(){

		System.out.println("Please choose from the following:\n1.Back to Login Menu\n2.Search Again\n->");
		int choice = 0;
		
		Scanner scan = new Scanner(System.in);
		if(scan.hasNextInt())
			choice = scan.nextInt();
		
		while(choice != 1 && choice != 2){
			System.out.println("Invalid input\nPlease choose from the following:\n1.Back to Login Menu\n2.Search Again\n->");
			if(scan.hasNextInt())
				choice = scan.nextInt();
			else 
				scan.next();
		}
		
		
		switch(choice){
		case 1:
			searchMovies();
			break;
		case 2:
			loginMenu();
			break;
		}
	}

	private static void searchByActor(){
		System.out.println("Please enter the name of the Actor you want to Search by\n->");
		Scanner sc = new Scanner(System.in).useDelimiter("\n");
		String actorName = sc.next();
		actorName = actorName.substring(0, actorName.length() - 1);
		Iterator<Entry<String, Movie>> it = moviesMap.entrySet().iterator();
		Boolean found = false;
		
		Vector<Movie> mov = new Vector<Movie>();
		
		while(it.hasNext()){		
			Map.Entry<String, Movie> pair  = (Map.Entry<String, Movie>) it.next();
			Movie m = (Movie) pair.getValue();
			Vector<String> actors = m.getActors();
			for(int i = 0; i < actors.size(); i++){
				if(actorName.equalsIgnoreCase(actors.get(i))){
					found = true;
					mov.add(m);
				}	
			}
			
		}
		
		if(found){
			System.out.println(mov.size() + " result(s):");
			for(int i = 0; i < mov.size(); i++){
				System.out.println(mov.get(i).getTitle());
			}
			
		}
		else
			System.out.println("Not Found");

		movieSearchToLogin();
		
		
	}
	
	private static void searchByTitle(){
		System.out.println("Please enter the title of the Movie you want to Search by\n->");
		Scanner sc = new Scanner(System.in).useDelimiter("\n");
		String movieTitle = sc.next();
		movieTitle = movieTitle.substring(0, movieTitle.length()-1);
		Boolean found = false;

		Iterator<Entry<String,Movie>> it = moviesMap.entrySet().iterator();
		Vector<String> movieMatches = new Vector<String>();
		while(it.hasNext()){
			Map.Entry<String, Movie> pair = (Map.Entry<String, Movie>) it.next();
			Movie m  = (Movie) pair.getValue();
			
			if(movieTitle.equalsIgnoreCase(m.getTitle())){
				found = true;
				movieMatches.add(m.getTitle());
			}
		}
		
		if(found){
			System.out.println(movieMatches.size() + " result(s)");
			for(int i = 0; i < movieMatches.size(); i++)
				System.out.println(movieMatches.get(i));
			
		}
		else{
			System.out.println("None Found");
		}
		
		movieSearchToLogin();


	}
	
	private static void searchByGenre(){
		System.out.println("Please enter the genre of the Movie you want to Search by\n->");
		Scanner sc = new Scanner(System.in).useDelimiter("\n");
		String genre = sc.next();
		genre = genre.substring(0, genre.length()-1);
		Boolean found = false;

		Iterator<Entry<String,Movie>> it = moviesMap.entrySet().iterator();
		Vector<String> movieMatches = new Vector<String>();
		while(it.hasNext()){
			Map.Entry<String, Movie> pair = (Map.Entry<String, Movie>) it.next();
			Movie m  = (Movie) pair.getValue();
			
			if(genre.equalsIgnoreCase(m.getGenre())){
				found = true;
				movieMatches.add(m.getTitle());
			}
		}
		
		if(found){
			System.out.println(movieMatches.size() + " result(s)");
			for(int i = 0; i < movieMatches.size(); i++)
				System.out.println(movieMatches.get(i));
		}
		else{
			System.out.println("None Found");
		}
		
		movieSearchToLogin();
	}
	
}
