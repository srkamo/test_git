
import java.util.Vector;

public class Movie {
	
	private String title;
	private String director;
	private Vector<String> writers;
	private Vector<String> actors;
	private String genre;
	private String description;
	private String year;
	private String avgRating;
	
	
	
	
	public Movie() {}
	
	public Movie(String title, String director, Vector<String> writers, 
			Vector<String> actors, String genre, String description, 
			String year,String avgRating) {
		super();
		this.title = title;
		this.director = director;
		this.writers = writers;
		this.actors = actors;
		this.genre = genre;
		this.description = description;
		this.year = year;
		this.avgRating = avgRating;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDirector() {
		return director;
	}
	public void setDirector(String director) {
		this.director = director;
	}
	public Vector<String> getWriters() {
		return writers;
	}
	public void setWriters(Vector<String> writers) {
		this.writers = writers;
	}
	public Vector<String> getActors() {
		return actors;
	}
	public void setActors(Vector<String> actors) {
		this.actors = actors;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getAvgRating() {
		return avgRating;
	}
	public void setAvgRating(String avgRating) {
		this.avgRating = avgRating;
	}
	
	
	
	
}
