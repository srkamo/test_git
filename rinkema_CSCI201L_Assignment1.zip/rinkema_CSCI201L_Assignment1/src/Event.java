
public class Event {

	private String action;
	private String movieTitle;
	private String rating;
	
	public Event(String action, String movieTitle, String rating){
		this.action = action;
		this.movieTitle = movieTitle;
		this.rating = rating;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getMovieTitle() {
		return movieTitle;
	}

	public void setMovieTitle(String movieTitle) {
		this.movieTitle = movieTitle;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}
	
	
}
