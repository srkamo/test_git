import java.util.Vector;

public class User {
	
	private Vector<String> actions;
	private Vector<String> following;
	private Vector<String> followers;
	private Vector<Event> feed;
	
	private String fName;
	private String lName;
	private String username;
	private String password;
	
	

	public User(Vector<String> following, Vector<Event> feed, String fName, String lName, String username,
			String password) {
		super();
		this.following = following;
		this.feed = feed;
		this.fName = fName;
		this.lName = lName;
		this.username = username;
		this.password = password;
		followers = new Vector<String>();
	}


	public Vector<String> getActions() {
		return actions;
	}

	public void setActions(Vector<String> actions) {
		this.actions = actions;
	}

	public Vector<String> getFollowing() {
		return following;
	}

	public void setFollowing(Vector<String> following) {
		this.following = following;
	}

	public Vector<String> getFollowers() {
		return followers;
	}
	
	public void addFollowers(String s){
		followers.addElement(s);
	}

	public void setFollowers(Vector<String> followers) {
		this.followers = followers;
	}

	public Vector<Event> getFeed() {
		return feed;
	}

	public void setFeed(Vector<Event> feed) {
		this.feed = feed;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	
}
